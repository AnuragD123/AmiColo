import React from 'react'
import Roomate from '../(Components)/Roomate/Roomate'

const contact = () => {
  return (
    <div className="min-h-screen">
      Contact Us

      <Roomate/>
    </div>
  )
}

export default contact
