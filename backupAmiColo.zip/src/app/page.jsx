export default function Home() {
  return (
    <main className="text-center">
      Home Page
    </main>
  );
}
